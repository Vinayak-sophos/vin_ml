import setuptools
setuptools.setup(
     name='vin_ml',  
     version='0.1',
     author="Vinayak Sachdeva",
     author_email="vishusachdeva228@gmail.com",
     description="My ML Lab Codes",
     url='https://github.com/Vinayak-sophos/vin_ml',
     packages=setuptools.find_packages(),
     classifiers=[
         "Programming Language :: Python :: 3",
         "Operating System :: OS Independent",
     ],
 )